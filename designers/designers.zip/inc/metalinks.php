<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="The official website of His & Hers Fashion Weekend by Zinny Styles, the organizers of His & Hers TV Series on Silverbird Television" />
<meta name="keywords" content="His, Hers, TV, Series, Fashion, Makeup, MUA, Branding, Personal Branding, TV Show, Zinny Styles" />
<meta name="author" content="Gabriel Eze" />

<link rel="shortcut icon" type="image/x-icon" href="../favicon.ico">
  
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">
<link rel="stylesheet" href="css/core.css">
<link rel="stylesheet" href="css/shortcode/shortcodes.css">

<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/custom.css">

<script src="js/vendor/modernizr-3.5.0.min.js"></script>