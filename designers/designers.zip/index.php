<!doctype html>
<html class="no-js" lang="en">
<head>
  <title>His&Hers &middash; The Fashion Directory</title>
  <?php include_once('inc/metalinks.php'); ?>
</head>

<body>
  <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
  <![endif]-->  

  <div class="wrapper">
    <?php include_once('inc/navbar.php'); ?>
    
    <!-- Start Top Rated Area -->
    <section class="top__rated__area bg__white pt--100 pb--110">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section__title--2 text-center">
              <h2 class="title__line">The Fashion Directory</h2>
              <p>An online market where people meet and connect with designers, tailors, makeup artists and other fashion brands with just one click.</p>
            </div>
          </div>
        </div>
        <div class="row mt--20">
          <!-- Start Single Product -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="htc__best__product">
              <div class="htc__best__pro__thumb">
                <a href="product-details.html">
                  <img src="images/product-2/sm-img-2/1.jpg" alt="small product">
                </a>
              </div>
              <div class="htc__best__product__details">
                <h2><a href="product-details.html">dummy Product title</a></h2>
                <ul class="rating">
                  <li><i class="icon-star icons"></i></li>
                  <li><i class="icon-star icons"></i></li>
                  <li><i class="icon-star icons"></i></li>
                  <li class="old"><i class="icon-star icons"></i></li>
                  <li class="old"><i class="icon-star icons"></i></li>
                </ul>
                <ul  class="top__pro__prize">
                  <li class="old__prize">$82.5</li>
                  <li>$75.2</li>
                </ul>
                <div class="best__product__action">
                  <ul class="product__action--dft">
                    <li><a href="wishlist.html"><i class="icon-heart icons"></i></a></li>
                    <li><a href="cart.html"><i class="icon-handbag icons"></i></a></li>
                    <li><a href="#"><i class="icon-shuffle icons"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <!-- End Single Product -->
          <!-- Start Single Product -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
              <div class="htc__best__product">
                  <div class="htc__best__pro__thumb">
                      <a href="product-details.html">
                          <img src="images/product-2/sm-img-2/2.jpg" alt="small product">
                      </a>
                  </div>
                  <div class="htc__best__product__details">
                      <h2><a href="product-details.html">dummy Product title</a></h2>
                      <ul class="rating">
                          <li><i class="icon-star icons"></i></li>
                          <li><i class="icon-star icons"></i></li>
                          <li><i class="icon-star icons"></i></li>
                          <li class="old"><i class="icon-star icons"></i></li>
                          <li class="old"><i class="icon-star icons"></i></li>
                      </ul>
                      <ul  class="top__pro__prize">
                          <li class="old__prize">$82.5</li>
                          <li>$75.2</li>
                      </ul>
                      <div class="best__product__action">
                          <ul class="product__action--dft">
                              <li><a href="wishlist.html"><i class="icon-heart icons"></i></a></li>
                              <li><a href="cart.html"><i class="icon-handbag icons"></i></a></li>
                              <li><a href="#"><i class="icon-shuffle icons"></i></a></li>
                          </ul>
                      </div>
                  </div>
              </div>
          </div>
          <!-- End Single Product -->
          <!-- Start Single Product -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="htc__best__product">
              <div class="htc__best__pro__thumb">
                  <a href="product-details.html">
                      <img src="images/product-2/sm-img-2/3.jpg" alt="small product">
                  </a>
              </div>
              <div class="htc__best__product__details">
                  <h2><a href="product-details.html">dummy Product title</a></h2>
                  <ul class="rating">
                      <li><i class="icon-star icons"></i></li>
                      <li><i class="icon-star icons"></i></li>
                      <li><i class="icon-star icons"></i></li>
                      <li class="old"><i class="icon-star icons"></i></li>
                      <li class="old"><i class="icon-star icons"></i></li>
                  </ul>
                  <ul  class="top__pro__prize">
                      <li class="old__prize">$82.5</li>
                      <li>$75.2</li>
                  </ul>
                  <div class="best__product__action">
                      <ul class="product__action--dft">
                          <li><a href="wishlist.html"><i class="icon-heart icons"></i></a></li>
                          <li><a href="cart.html"><i class="icon-handbag icons"></i></a></li>
                          <li><a href="#"><i class="icon-shuffle icons"></i></a></li>
                      </ul>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <!-- Start Footer Area -->
    <?php include_once('inc/footer.php'); ?>
  </div>
  <!-- Body main wrapper end -->

  <!-- Placed js at the end of the document so the pages load faster -->

  <!-- jquery latest version -->
  <script src="js/vendor/jquery-3.2.1.min.js"></script>
  <!-- Bootstrap framework js -->
  <script src="js/bootstrap.min.js"></script>
  <!-- All js plugins included in this file. -->
  <script src="js/plugins.js"></script>
  <script src="js/slick.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <!-- Waypoints.min.js. -->
  <script src="js/waypoints.min.js"></script>
  <!-- Main js file that contents all jQuery plugins activation. -->
  <script src="js/main.js"></script>

</body>

</html>